class FuelStation:
    def __init__(self, diesel, petrol, electric):

        self.total_spots = {"diesel": diesel,"petrol": petrol,"electric": electric}
        self.occupied_spots = {"diesel": 0,"petrol": 0,"electric": 0}

    def fuel_vehicle(self, fuel_type):
  
        if self.occupied_spots[fuel_type] < self.total_spots[fuel_type]:
            self.occupied_spots[fuel_type] += 1
            return fuel_type,True          
        return fuel_type,False

    def open_fuel_slot(self, fuel_type):
        
        if self.occupied_spots[fuel_type] >=1 :            
            self.occupied_spots[fuel_type] -= 1
            return fuel_type,False
        return fuel_type,True


fuel_station = FuelStation(diesel=1, petrol=2, electric=1)

print("############Occupied Slots##############")
print()

print(fuel_station.fuel_vehicle("diesel"))
print(fuel_station.fuel_vehicle("petrol"))
print(fuel_station.fuel_vehicle("electric"))
print(fuel_station.fuel_vehicle("electric"))

print()
print("#############Open Slots#################")

print(fuel_station.open_fuel_slot("diesel"))
print(fuel_station.open_fuel_slot("petrol")) 
print(fuel_station.open_fuel_slot("electric")) 
