class DataStream:
    def __init__(self):
        
        self.last_print_time = {}
        
    def should_output_data_str(self, timestamp, data_string):

        if self.last_print_time.get(data_string)==None:
            self.last_print_time[data_string] = timestamp            
            return True

        if timestamp - self.last_print_time[data_string] >= 5:
            self.last_print_time[data_string] = timestamp
            timeValue=timestamp - self.last_print_time[data_string]
            return True
  
        else:
            self.last_print_time[data_string] = timestamp
            return False



data_stream = DataStream()

data_stream_1=data_stream.should_output_data_str(timestamp=0, data_string="hello")

data_stream_2=data_stream.should_output_data_str(timestamp=1, data_string="world")

data_stream_3=data_stream.should_output_data_str(timestamp=6, data_string="hello")

data_stream_4=data_stream.should_output_data_str(timestamp=7, data_string="hello")

data_stream_5=data_stream.should_output_data_str(timestamp=8, data_string="world")

print(data_stream_1)
print(data_stream_2)
print(data_stream_3)
print(data_stream_4)
print(data_stream_5)