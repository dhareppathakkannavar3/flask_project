class Node():
    def __init__(self, start: int, end: int):
        self.start: int = start
        self.end: int = end
        self.left_child: Optional[Node] = None
        self.right_child: Optional[Node] = None

    def insert(self, node: 'Node') -> bool:
        if node.start <= self.end:
            if not self.right_child:
                self.right_child = node
                return True
            return self.left_child.insert(node)
        elif node.end >= self.start:
            if not self.left_child:
                self.left_child = node
                return True
            return self.left_child.insert(node)

class Calendar():
    def __init__(self):
        self.root: Node = None
        self.prevCalender={}
        self.events=0
    def book(self, start: int, end: int) -> bool:
    
        if self.root is None:
            self.events+=1
            self.prevCalender["prevData"+str(self.events)]=[i for i in range(start,end+1)]
            self.root = Node(start=start, end=end)        
            return True
            
        else:
            self.events+=1
            bookFlag=True

            for event,slot in self.prevCalender.items():            
                if start in slot or end in slot:
                    bookFlag=False

                    
            self.prevCalender["prevData"+str(self.events)]=[i for i in range(start,end+1)]
            
            return bookFlag
        
        return self.root.insert(node=Node(start, end))

calendar=Calendar()
event1=calendar.book(5,10)
event2=calendar.book(8,13)
event3=calendar.book(14,16)
print(event1,event2,event3)